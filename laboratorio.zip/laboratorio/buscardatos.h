#include <iostream>
#include <vector>
using namespace std;

#ifndef BUSCARDATOS_H_INCLUDED
#define BUSCARDATOS_H_INCLUDED
 void buscaringes (vector<datos> &info){
 string buscador;
 cout << "INGRESE EL NOMBRE A BUSCAR"<<endl;
 cin>>buscador;

 for (size_t i=0;i<info.size();i++){
 if (info[i].nombre==buscador){
 cout << "SE ENCONTRO A: "<<"["<<buscador<<"]"<<endl;
 }else{
 cout << "NO SE ENCONTRO A: "<<"["<<buscador<<"]"<<endl;
        }
    }
 }


#endif // BUSCARDATOS_H_INCLUDED
