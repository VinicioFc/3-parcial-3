#include <iostream>
#include <vector>
using namespace std;

#ifndef MOSTARDATOS_H_INCLUDED
#define MOSTARDATOS_H_INCLUDED

void mostraringes (vector<datos>&info){
for (size_t i=0;i<info.size();i++){
 cout << "SU NOMBRE ES: "<<info[i].nombre<<endl;
 cout<< "SU EDAD ES: "<<info[i].edad<<endl;

}

}

#endif // MOSTARDATOS_H_INCLUDED
