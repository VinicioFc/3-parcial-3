#include <iostream>
#include <vector>
#include "C:\Users\Labs-G300\Desktop\Fundamentos\2p\laboratorio\creardatos.h"
#include "C:\Users\Labs-G300\Desktop\Fundamentos\2p\laboratorio\mostardatos.h"
#include "C:\Users\Labs-G300\Desktop\Fundamentos\2p\laboratorio\buscardatos.h"
using namespace std;

vector<datos> info;
string buscador;

int main()
{
int opcion;
do{
        cout<< "--SU MENU DE OPCIONES--"<<endl;
        cout << "1.- CREAR"<<endl;
        cout << "2.- MOSTAR"<<endl;
        cout << "3.- BUSCAR"<<endl;
        cout << "ELIJA UNA OPCION"<<endl;
        cin>>opcion;

        switch (opcion){
    case 1:
        crearinges(info);
        break;
    case 2:
        mostraringes(info);
        break;
    case 3:
        buscaringes (info);
        break;
        }
}while (opcion != 3);
    return 0;
}
