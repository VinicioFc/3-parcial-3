#include <iostream>
#include <vector>
#include <cstdlib>
using namespace std;

#ifndef CREARDATOS_H_INCLUDED
#define CREARDATOS_H_INCLUDED

struct datos {
string nombre;
int edad;
};

void crearinges (vector<datos> &info){

for (int i=0;i<2;i++){
    datos fungi;

    cout << "INGRESE EL NOMBRE"<<"["<<i<<"]"<<endl;
    cin>>fungi.nombre;
    cout << "INGRESE EL EDAD"<<"["<<i<<"]"<<endl;
    cin>>fungi.edad;
    info.push_back(fungi);
    system ("cls");
 }
}


#endif // CREARDATOS_H_INCLUDED
